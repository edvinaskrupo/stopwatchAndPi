package com.company;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;

/**
 * A program that can use multiple threads
 * to create multiple working Stopwatches
 * and Pi calculators.
 * @author Edvinas Krupovnickas
 */
public class Main extends Canvas {
    public static void main(String[] args) throws IOException {

        //initializing the frame
        JFrame f = new JFrame("Choose a task");

        //stopwatch button
        JButton stopwatchButton = new JButton("Start Stopwatch");
        f.add(stopwatchButton);
        stopwatchButton.setBounds(100, 50, 200, 100);

        //calculate pi button
        JButton calculatePiButton = new JButton("Calculate π");
        f.add(calculatePiButton);
        calculatePiButton.setBounds(100, 200, 200, 100);

        //frame options
        f.setSize(400,400);
        f.setLayout(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
        f.setLocationRelativeTo(null);

        //stopwatch window
        stopwatchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Thread stopwatchThread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        final boolean[] threadRunning = {true};
                        //new frame
                        JFrame stopwatchFrame = new JFrame("Stopwatch");

                        //adding an image of a stopwatch to the frame
                        JButton stopwatchImage = new JButton();
                        stopwatchFrame.add(stopwatchImage);
                        stopwatchImage.setEnabled(false);
                        stopwatchImage.setIcon(new ImageIcon("Stopwatch.jpg"));
                        stopwatchImage.setDisabledIcon(new ImageIcon("Stopwatch.jpg"));
                        stopwatchImage.setBounds(100, 100, 400, 400);

                        //stop button (frame)
                        JButton stopButton = new JButton("Stop");
                        stopwatchFrame.add(stopButton);
                        stopButton.setBounds(150, 25, 300, 50);

                        //stop button (functionality)
                        final double[] i = {0};
                        stopButton.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                                threadRunning[0] = false;
                                try {
                                    FileWriter myWriter = new FileWriter("results.txt", true);
                                    myWriter.write("-----------Stopwatch-----------\n");
                                    myWriter.write("Time elapsed: " + String.valueOf((i[0] + 1) / 10) + " seconds\n");
                                    myWriter.write("-------------------------------\n\n");
                                    myWriter.close();
                                } catch (IOException ioException) {
                                    System.out.println("Could not create file!");
                                    ioException.printStackTrace();
                                }
                            }
                        });

                        //time elapsed
                        JLabel timeElapsed = new JLabel("Time elapsed: 0");
                        stopwatchFrame.add(timeElapsed);
                        timeElapsed.setBounds(250, 475, 150, 100);

                        //frame options
                        stopwatchFrame.setSize(600,600);
                        stopwatchFrame.setLayout(null);
                        stopwatchFrame.setVisible(true);
                        stopwatchFrame.setDefaultCloseOperation(f.EXIT_ON_CLOSE);

                        //increases the elapsed time of the stopwatch
                        while (threadRunning[0]) {
                            try {
                                Thread.sleep(100);
                                i[0]++;
                            } catch(InterruptedException e) {
                                e.printStackTrace();
                            }
                            timeElapsed.setText("Time elapsed: " + i[0]/10);
                        }

                    }
                });
                stopwatchThread.start();
            }
        });

        //Pi calculation window
        calculatePiButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Thread calculatePiThread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        final boolean[] threadRunning = {true};
                        //new frame
                        JFrame calculatePiFrame = new JFrame("Calculating π...");

                        //adding an image of the letter π to the frame
                        JButton stopwatchImage = new JButton();
                        calculatePiFrame.add(stopwatchImage);
                        stopwatchImage.setEnabled(false);
                        stopwatchImage.setIcon(new ImageIcon("Letter-Pi.png"));
                        stopwatchImage.setDisabledIcon(new ImageIcon("Letter-Pi.png"));
                        stopwatchImage.setBounds(200, 100, 200, 200);

                        //pi value label
                        JLabel piEquals = new JLabel("<html>Pi is equal to:<br> 3.14<html>");
                        calculatePiFrame.add(piEquals);
                        piEquals.setBounds(50, 175, 500, 500);

                        //stop button (frame)
                        JButton stopButton = new JButton("Stop");
                        calculatePiFrame.add(stopButton);
                        stopButton.setBounds(150, 25, 300, 50);

                        //stop button (functionality)
                        final double[] i = {3};
                        stopButton.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                                threadRunning[0] = false;
                                try {
                                    FileWriter myWriter = new FileWriter("results.txt", true);
                                    myWriter.write("-----------Pi Calculation-----------\n");
                                    myWriter.write("Pi evaluated at:\n3.14" + piEquals.getText().replaceAll("<br>", "\n").
                                            replaceFirst("<html>Pi is equal to:\n 3.14<html>", "")+ "\n");
                                    myWriter.write("Time elapsed: " + String.valueOf((i[0] - 2) / 10) + " seconds\n");
                                    myWriter.write("------------------------------------\n\n");
                                    myWriter.close();
                                } catch (IOException ioException) {
                                    System.out.println("Could not create file!");
                                    ioException.printStackTrace();
                                }
                            }
                        });

                        //frame options
                        calculatePiFrame.setSize(600,600);
                        calculatePiFrame.setLayout(null);
                        calculatePiFrame.setVisible(true);
                        calculatePiFrame.setDefaultCloseOperation(f.EXIT_ON_CLOSE);

                        //calculating Pi
                        Pi p = new Pi();
                        while (threadRunning[0]) {
                            try {
                                Thread.sleep(100);
                                piEquals.setText(piEquals.getText() + p.calcPiDigits((int) i[0]));
                                i[0]++;
                                //newline
                                if (i[0] % 71 == 0) {
                                    piEquals.setText(piEquals.getText() + "<br>");
                                }
                            } catch(InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                });
                calculatePiThread.start();
            }
        });
    }
}
